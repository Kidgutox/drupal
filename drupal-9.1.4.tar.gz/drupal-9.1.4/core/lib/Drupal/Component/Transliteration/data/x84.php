<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'hu', 'qi', 'he', 'cui', 'tao', 'chun', 'bi', 'chang', 'huan', 'fei', 'lai', 'qi', 'meng', 'ping', 'wei', 'dan',
  0x10 => 'sha', 'huan', 'yan', 'yi', 'tiao', 'qi', 'wan', 'ce', 'nai', 'zhen', 'tuo', 'jiu', 'tie', 'luo', 'bi', 'yi',
  0x20 => 'meng', 'bo', 'pao', 'ding', 'ying', 'ying', 'ying', 'xiao', 'sa', 'qiu', 'ke', 'xiang', 'wan', 'yu', 'yu', 'fu',
  0x30 => 'lian', 'xuan', 'xuan', 'nan', 'ce', 'wo', 'chun', 'xiao', 'yu', 'bian', 'mao', 'an', 'e', 'luo', 'ying', 'kuo',
  0x40 => 'kuo', 'jiang', 'mian', 'zuo', 'zuo', 'zu', 'bao', 'rou', 'xi', 'ye', 'an', 'qu', 'jian', 'fu', 'lu', 'jing',
  0x50 => 'pen', 'feng', 'hong', 'hong', 'hou', 'yan', 'tu', 'zhe', 'zi', 'xiang', 'ren', 'ge', 'qia', 'qing', 'mi', 'huang',
  0x60 => 'shen', 'pu', 'gai', 'dong', 'zhou', 'jian', 'wei', 'bo', 'wei', 'pa', 'ji', 'hu', 'zang', 'jia', 'duan', 'yao',
  0x70 => 'sui', 'cong', 'quan', 'wei', 'zhen', 'kui', 'ting', 'hun', 'xi', 'shi', 'qi', 'lan', 'zong', 'yao', 'yuan', 'mei',
  0x80 => 'yun', 'shu', 'di', 'zhuan', 'guan', 'ran', 'xue', 'chan', 'kai', 'kui', 'hua', 'jiang', 'lou', 'wei', 'pai', 'you',
  0x90 => 'sou', 'yin', 'shi', 'chun', 'shi', 'yun', 'zhen', 'lang', 'ru', 'meng', 'li', 'que', 'suan', 'yuan', 'li', 'ju',
  0xA0 => 'xi', 'bang', 'chu', 'xu', 'tu', 'liu', 'huo', 'dian', 'qian', 'zu', 'po', 'cuo', 'yuan', 'chu', 'yu', 'kuai',
  0xB0 => 'pan', 'pu', 'pu', 'na', 'shuo', 'xi', 'fen', 'yun', 'zheng', 'jian', 'ji', 'ruo', 'cang', 'en', 'mi', 'hao',
  0xC0 => 'sun', 'zhen', 'ming', 'sou', 'xu', 'liu', 'xi', 'gu', 'lang', 'rong', 'weng', 'gai', 'cuo', 'shi', 'tang', 'luo',
  0xD0 => 'ru', 'suo', 'xuan', 'bei', 'yao', 'gui', 'bi', 'zong', 'gun', 'zuo', 'tiao', 'ce', 'pei', 'lan', 'dan', 'ji',
  0xE0 => 'li', 'shen', 'lang', 'yu', 'ling', 'ying', 'mo', 'diao', 'tiao', 'mao', 'tong', 'chu', 'peng', 'an', 'lian', 'cong',
  0xF0 => 'xi', 'ping', 'qiu', 'jin', 'chun', 'jie', 'wei', 'tui', 'cao', 'yu', 'yi', 'zi', 'liao', 'bi', 'lu', 'xu',
];
